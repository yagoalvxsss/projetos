<?php
// cadastrar-venda.php
// Carrega conexao e listas de referencias (clientes, funcionarios, modelos)
require_once __DIR__ . '/config.php';

if (!isset($conn) || !($conn instanceof mysqli)) {
    echo "<h1>Cadastrar Venda</h1>";
    echo "<p style='color:red;'>Conexão com o banco não encontrada. Verifique config.php</p>";
    return;
}

// buscar clientes
$clientes = [];
$res = $conn->query("SELECT id_cliente, nome_cliente FROM cliente ORDER BY nome_cliente");
if ($res) while ($r = $res->fetch_assoc()) $clientes[] = $r;

// buscar funcionarios
$funcionarios = [];
$res = $conn->query("SELECT id_funcionario, nome_funcionario FROM funcionario ORDER BY nome_funcionario");
if ($res) while ($r = $res->fetch_assoc()) $funcionarios[] = $r;

// buscar modelos
$modelos = [];
$res = $conn->query("SELECT id_modelo, nome_modelo FROM modelo ORDER BY nome_modelo");
if ($res) while ($r = $res->fetch_assoc()) $modelos[] = $r;
?>
<h1>Cadastrar Venda</h1>

<form action="?page=salvar-venda" method="POST">
    <input type="hidden" name="acao" value="cadastrar">

    <div class="mb-3">
        <label>Cliente</label>
        <select name="cliente_id_cliente" class="form-control" required>
            <option value="">Escolha</option>
            <?php
            if (!empty($clientes)) {
                foreach ($clientes as $c) {
                    $id = htmlspecialchars($c['id_cliente']);
                    $nome = htmlspecialchars($c['nome_cliente']);
                    echo "<option value='{$id}'>{$nome}</option>";
                }
            } else {
                echo "<option value=''>Nenhum cliente</option>";
            }
            ?>
        </select>
    </div>

    <div class="mb-3">
        <label>Vendedor (Funcionário)</label>
        <select name="funcionario_id_funcionario" class="form-control" required>
            <option value="">Escolha</option>
            <?php
            if (!empty($funcionarios)) {
                foreach ($funcionarios as $f) {
                    $id = htmlspecialchars($f['id_funcionario']);
                    $nome = htmlspecialchars($f['nome_funcionario']);
                    echo "<option value='{$id}'>{$nome}</option>";
                }
            } else {
                echo "<option value=''>Nenhum funcionário</option>";
            }
            ?>
        </select>
    </div>

    <div class="mb-3">
        <label>Modelo</label>
        <select name="modelo_id_modelo" class="form-control" required>
            <option value="">Escolha</option>
            <?php
            if (!empty($modelos)) {
                foreach ($modelos as $m) {
                    $id = htmlspecialchars($m['id_modelo']);
                    $nome = htmlspecialchars($m['nome_modelo']);
                    echo "<option value='{$id}'>{$nome}</option>";
                }
            } else {
                echo "<option value=''>Nenhum modelo</option>";
            }
            ?>
        </select>
    </div>

    <div class="mb-3">
        <label>Valor</label>
        <input type="number" step="0.01" name="valor_venda" class="form-control" placeholder="0.00" required>
    </div>

    <div class="mb-3">
        <label>Data da Venda</label>
        <input type="date" name="data_venda" class="form-control" value="<?php echo date('Y-m-d'); ?>" required>
    </div>

    <div>
        <button type="submit" class="btn btn-primary">Enviar</button>
    </div>
</form>