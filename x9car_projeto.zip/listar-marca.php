<?php
// listar-marca.php - versão de debug
// ajuste o caminho se o config.php estiver em outra pasta
require_once __DIR__ . '/config.php';

// mostrar erros temporariamente para debug
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo "<h1>Listar Marca</h1>";

// checar conexão
if (!isset($conn) || !($conn instanceof mysqli)) {
    echo "<p style='color:red;'>Conexão com o banco não encontrada. Verifique config.php</p>";
    return;
}

// checar qual DB estamos usando (debug)
echo "<p>Conectado ao host: " . htmlspecialchars($conn->host_info) . " — DB: " . htmlspecialchars($conn->real_escape_string($conn->query("SELECT DATABASE()")->fetch_row()[0] ?? '')) . "</p>";

$sql = "SELECT * FROM marca ORDER BY id_marca";
$res = $conn->query($sql);

if ($res === false) {
    echo "<p style='color:red;'>Erro na query: " . htmlspecialchars($conn->error) . "</p>";
    return;
}

if ($res->num_rows === 0) {
    echo "<p>Nenhuma marca encontrada (num_rows = 0).</p>";
    // mostrar estrutura da tabela se existir
    $t = $conn->query("SHOW TABLES LIKE 'marca'");
    if ($t && $t->num_rows === 0) {
        echo "<p style='color:darkred;'>Tabela <b>marca</b> não existe neste banco.</p>";
    } else {
        echo "<p>Tabela <b>marca</b> existe mas está vazia.</p>";
    }
    return;
}

// se chegou aqui, tem resultados
echo "<p>Encontrou <b>{$res->num_rows}</b> resultado(s)</p>";
echo "<table class='table table-bordered table-striped table-hover'>";
echo "<tr><th>#</th><th>Nome</th></tr>";
while ($row = $res->fetch_assoc()) {
    echo "<tr>";
    echo "<td>" . htmlspecialchars($row['id_marca']) . "</td>";
    echo "<td>" . htmlspecialchars($row['nome_marca']) . "</td>";
    echo "</tr>";
}
echo "</table>";
?>