<?php
require_once __DIR__ . '/config.php';

if (!isset($conn) || !($conn instanceof mysqli)) {
    echo "<h1>Listar Cliente</h1>";
    echo "<p style='color:darkred;'>Conexão com o banco não encontrada. Verifique config.php</p>";
    return;
}
?>
<h1>Listar Cliente</h1>
<?php
$sql = "SELECT * FROM cliente ORDER BY id_cliente";
$res = $conn->query($sql);

if ($res && $res->num_rows > 0) {
    $qtd = $res->num_rows;
    print "<p>Encontrou <b>$qtd</b> resultado(s)</p>";
    print "<table class='table table-bordered table-striped table-hover'>";
    print "<tr><th>#</th><th>Nome</th><th>CPF</th><th>E-mail</th><th>Telefone</th><th>Ações</th></tr>";
    while ($row = $res->fetch_object()) {
        $id = htmlspecialchars($row->id_cliente);
        $nome = htmlspecialchars($row->nome_cliente);
        $cpf = htmlspecialchars($row->cpf_cliente);
        $email = htmlspecialchars($row->email_cliente);
        $telefone = htmlspecialchars($row->telefone_cliente);
        print "<tr>";
        print "<td>{$id}</td>";
        print "<td>{$nome}</td>";
        print "<td>{$cpf}</td>";
        print "<td>{$email}</td>";
        print "<td>{$telefone}</td>";
        print "<td>";
        print "<button class='btn btn-success' onclick=\"location.href='?page=editar-cliente&id_cliente={$id}'\">Editar</button> ";
        print "<form method='post' action='?page=salvar-cliente' style='display:inline-block;margin:0 4px;'>";
        print "<input type='hidden' name='acao' value='excluir'>";
        print "<input type='hidden' name='id_cliente' value='{$id}'>";
        print "<button type='submit' class='btn btn-danger' onclick=\"return confirm('Tem certeza que deseja excluir?')\">Excluir</button>";
        print "</form>";
        print "</td>";
        print "</tr>";
    }
    print "</table>";
} else {
    print "<p>Não há resultado(s)</p>";
}
?>