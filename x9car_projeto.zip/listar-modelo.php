<?php

require_once __DIR__ . '/config.php';

// debug leve (remova em produção)
ini_set('display_errors', 1);
error_reporting(E_ALL);

echo "<h1>Listar Modelo</h1>";

// checar conexão
if (!isset($conn) || !($conn instanceof mysqli)) {
    echo "<p style='color:red;'>Conexão com o banco não encontrada. Verifique config.php</p>";
    exit;
}

// buscar modelos com o nome da marca (se houver)
$sql = "SELECT m.id_modelo,
               m.nome_modelo,
               m.cor_modelo,
               m.ano_modelo,
               m.tipo_modelo,
               m.marca_id_marca,
               COALESCE(ma.nome_marca, '(sem marca)') AS nome_marca
        FROM modelo m
        LEFT JOIN marca ma ON m.marca_id_marca = ma.id_marca
        ORDER BY m.id_modelo DESC";

$res = $conn->query($sql);

if ($res === false) {
    echo "<p style='color:red;'>Erro na query: " . htmlspecialchars($conn->error) . "</p>";
    exit;
}

if ($res->num_rows === 0) {
    echo "<p>Não há modelos cadastrados.</p>";
    // Opção: mostrar se a tabela existe para ajudar debug
    $t = $conn->query("SHOW TABLES LIKE 'modelo'");
    if (!($t && $t->num_rows > 0)) {
        echo "<p style='color:darkred;'>A tabela <b>modelo</b> não existe neste banco.</p>";
    }
    exit;
}

// exibir tabela
echo "<p>Encontrou <b>{$res->num_rows}</b> resultado(s)</p>";
echo "<table class='table table-bordered table-striped table-hover'>";
echo "<thead><tr><th>#</th><th>Nome</th><th>Marca</th><th>Ano</th><th>Cor</th><th>Tipo</th><th>Ações</th></tr></thead>";
echo "<tbody>";

while ($row = $res->fetch_assoc()) {
    $id = htmlspecialchars($row['id_modelo']);
    $nome = htmlspecialchars($row['nome_modelo']);
    $marca = htmlspecialchars($row['nome_marca']);
    $ano = htmlspecialchars($row['ano_modelo']);
    $cor = htmlspecialchars($row['cor_modelo']);
    $tipo = htmlspecialchars($row['tipo_modelo']);

    echo "<tr>";
    echo "<td>{$id}</td>";
    echo "<td>{$nome}</td>";
    echo "<td>{$marca}</td>";
    echo "<td>{$ano}</td>";
    echo "<td>{$cor}</td>";
    echo "<td>{$tipo}</td>";
    echo "<td>";
    echo "<button class='btn btn-success btn-sm' onclick=\"location.href='?page=editar-modelo&id_modelo={$id}'\">Editar</button> ";

    echo "<form method='post' action='?page=salvar-modelo' style='display:inline-block;margin:0 4px;'>";
    echo "<input type='hidden' name='acao' value='excluir'>";
    echo "<input type='hidden' name='id_modelo' value='{$id}'>";
    echo "<button type='submit' class='btn btn-danger btn-sm' onclick=\"return confirm('Tem certeza que deseja excluir?')\">Excluir</button>";
    echo "</form>";

    echo "</td>";
    echo "</tr>";
}

echo "</tbody></table>";
?>