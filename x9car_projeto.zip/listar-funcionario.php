<?php
require_once __DIR__ . '/config.php'; // ajuste o caminho conforme sua estrutura

if (!isset($conn) || !($conn instanceof mysqli)) {
    die('Conexão inválida. Verifique o arquivo config.php');
}
?>
<h1>Listar Funcionário</h1>
<?php
$sql = "SELECT * FROM funcionario ORDER BY id_funcionario";
$res = $conn->query($sql);

if ($res && $res->num_rows > 0) {
    $qtd = $res->num_rows;
    print "<p>Encontrou <b>$qtd</b> resultado(s)</p>";
    print "<table class='table table-bordered table-striped table-hover'>";
    print "<tr>";
    print "<th>#</th>";
    print "<th>Nome</th>";
    print "<th>E-mail</th>";
    print "<th>Telefone</th>";
    print "<th>Ações</th>";
    print "</tr>";
    while ($row = $res->fetch_object()) {
        $id = htmlspecialchars($row->id_funcionario);
        $nome = htmlspecialchars($row->nome_funcionario);
        $email = htmlspecialchars($row->email_funcionario);
        $telefone = htmlspecialchars($row->telefone_funcionario);

        print "<tr>";
        print "<td>{$id}</td>";
        print "<td>{$nome}</td>";
        print "<td>{$email}</td>";
        print "<td>{$telefone}</td>";
        print "<td>";
        print "<button class='btn btn-success' onclick=\"location.href='?page=editar-funcionario&id_funcionario={$id}'\">Editar</button> ";

        print "<form method='post' action='?page=salvar-funcionario' style='display:inline-block;margin:0 4px;'>";
        print "<input type='hidden' name='acao' value='excluir'>";
        print "<input type='hidden' name='id_funcionario' value='{$id}'>";
        print "<button type='submit' class='btn btn-danger' onclick=\"return confirm('Tem certeza que deseja excluir?')\">Excluir</button>";
        print "</form>";

        print "</td>";
        print "</tr>";
    }
    print "</table>";
} else {
    print "<p>Não há resultado(s)</p>";
}
?>