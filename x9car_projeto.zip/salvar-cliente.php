<?php
require_once 'config.php';
$acao = $_REQUEST['acao'] ?? '';
switch ($acao) {
    case 'cadastrar':
        $nome = trim($_POST['nome_cliente'] ?? '');
        $cpf = trim($_POST['cpf_cliente'] ?? '');
        $email = trim($_POST['email_cliente'] ?? '');
        $telefone = trim($_POST['telefone_cliente'] ?? '');
        $endereco = trim($_POST['endereco_cliente'] ?? '');
        $dt_nasc = $_POST['dt_nasc_cliente'] ?? null;

        if ($nome === '') {
            print "<script>alert('Nome obrigatório'); location.href='?page=cadastrar-cliente';</script>";
            exit;
        }

        $stmt = $conn->prepare("INSERT INTO cliente (nome_cliente, cpf_cliente, email_cliente, telefone_cliente, endereco_cliente, dt_nasc_cliente) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $nome, $cpf, $email, $telefone, $endereco, $dt_nasc);
        $ok = $stmt->execute();
        if ($ok) {
            print "<script>alert('Cadastrou com sucesso!'); location.href='?page=listar-cliente';</script>";
        } else {
            print "<script>alert('Erro ao cadastrar'); location.href='?page=listar-cliente';</script>";
        }
        break;

    case 'editar':
        $id = intval($_POST['id_cliente'] ?? 0);
        $nome = trim($_POST['nome_cliente'] ?? '');
        $cpf = trim($_POST['cpf_cliente'] ?? '');
        $email = trim($_POST['email_cliente'] ?? '');
        $telefone = trim($_POST['telefone_cliente'] ?? '');
        $endereco = trim($_POST['endereco_cliente'] ?? '');
        $dt_nasc = $_POST['dt_nasc_cliente'] ?? null;

        if ($id <= 0 || $nome === '') {
            print "<script>alert('Dados inválidos'); location.href='?page=listar-cliente';</script>";
            exit;
        }

        $stmt = $conn->prepare("UPDATE cliente SET nome_cliente = ?, cpf_cliente = ?, email_cliente = ?, telefone_cliente = ?, endereco_cliente = ?, dt_nasc_cliente = ? WHERE id_cliente = ?");
        $stmt->bind_param("ssssssi", $nome, $cpf, $email, $telefone, $endereco, $dt_nasc, $id);
        $ok = $stmt->execute();
        if ($ok) {
            print "<script>alert('Editou com sucesso!'); location.href='?page=listar-cliente';</script>";
        } else {
            print "<script>alert('Erro ao editar'); location.href='?page=listar-cliente';</script>";
        }
        break;

    case 'excluir':
        $id = intval($_POST['id_cliente'] ?? 0);
        if ($id <= 0) {
            print "<script>alert('ID inválido'); location.href='?page=listar-cliente';</script>";
            exit;
        }
        $stmt = $conn->prepare("DELETE FROM cliente WHERE id_cliente = ?");
        $stmt->bind_param("i", $id);
        $ok = $stmt->execute();
        if ($ok) {
            print "<script>alert('Excluiu com sucesso!'); location.href='?page=listar-cliente';</script>";
        } else {
            print "<script>alert('Erro ao excluir'); location.href='?page=listar-cliente';</script>";
        }
        break;

    default:
        header('Location: ?page=listar-cliente');
        exit;
}
?>