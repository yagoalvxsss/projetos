<?php
// salvar-marca.php
require_once __DIR__ . '/config.php';

// debug temporário (remova em produção)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($conn) || !($conn instanceof mysqli)) {
    print "<script>alert('Conexão com o banco não encontrada. Verifique config.php'); location.href='?page=cadastrar-marca';</script>";
    exit;
}

$acao = $_REQUEST['acao'] ?? '';

switch ($acao) {
    case 'cadastrar':
        $nome = trim($_POST['nome_marca'] ?? '');
        if ($nome === '') {
            print "<script>alert('Nome obrigatório'); location.href='?page=cadastrar-marca';</script>";
            exit;
        }

        $stmt = $conn->prepare("INSERT INTO marca (nome_marca) VALUES (?)");
        if (!$stmt) {
            // mostrar erro de prepare
            $err = $conn->error;
            error_log("Prepare failed: $err");
            die("<script>alert('Erro no banco (prepare): ".htmlspecialchars($err)."'); location.href='?page=cadastrar-marca';</script>");
        }

        $stmt->bind_param("s", $nome);
        $ok = $stmt->execute();
        if ($ok) {
            print "<script>alert('Cadastrou com sucesso!'); location.href='?page=listar-marca';</script>";
            exit;
        } else {
            // mostra erro detalhado para debug
            $err = $stmt->error ?: $conn->error;
            error_log("Execute failed: $err");
            die("<script>alert('Erro ao cadastrar: ".htmlspecialchars($err)."'); location.href='?page=cadastrar-marca';</script>");
        }
        break;

    case 'editar':
        // implementação de editar (se já tiver)
        $id = intval($_POST['id_marca'] ?? 0);
        $nome = trim($_POST['nome_marca'] ?? '');
        if ($id <= 0 || $nome === '') {
            print "<script>alert('Dados inválidos'); location.href='?page=listar-marca';</script>";
            exit;
        }
        $stmt = $conn->prepare("UPDATE marca SET nome_marca = ? WHERE id_marca = ?");
        $stmt->bind_param("si", $nome, $id);
        $ok = $stmt->execute();
        if ($ok) {
            print "<script>alert('Editou com sucesso!'); location.href='?page=listar-marca';</script>";
        } else {
            $err = $stmt->error ?: $conn->error;
            die("<script>alert('Erro ao editar: ".htmlspecialchars($err)."'); location.href='?page=listar-marca';</script>");
        }
        break;

    case 'excluir':
        $id = intval($_POST['id_marca'] ?? 0);
        if ($id <= 0) {
            print "<script>alert('ID inválido'); location.href='?page=listar-marca';</script>";
            exit;
        }
        $stmt = $conn->prepare("DELETE FROM marca WHERE id_marca = ?");
        $stmt->bind_param("i", $id);
        $ok = $stmt->execute();
        if ($ok) {
            print "<script>alert('Excluiu com sucesso!'); location.href='?page=listar-marca';</script>";
        } else {
            $err = $stmt->error ?: $conn->error;
            die("<script>alert('Erro ao excluir: ".htmlspecialchars($err)."'); location.href='?page=listar-marca';</script>");
        }
        break;

    default:
        header('Location: ?page=listar-marca');
        exit;
}
?>