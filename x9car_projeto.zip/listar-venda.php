<?php
// listar-venda.php
// Listagem de vendas no mesmo estilo das outras listagens (Bootstrap-like table, ações, mensagens)
require_once __DIR__ . '/config.php';

// checagem de conexão
if (!isset($conn) || !($conn instanceof mysqli)) {
    echo "<h1>Listar Venda</h1>";
    echo "<p style='color:red;'>Conexão com o banco não encontrada. Verifique config.php</p>";
    return;
}

// buscar vendas com nomes relacionados (cliente, funcionário, modelo)
$sql = "SELECT v.id_venda,
               v.valor_venda,
               v.data_venda,
               v.cliente_id_cliente,
               v.funcionario_id_funcionario,
               v.modelo_id_modelo,
               c.nome_cliente,
               f.nome_funcionario,
               mo.nome_modelo
        FROM venda v
        LEFT JOIN cliente c ON v.cliente_id_cliente = c.id_cliente
        LEFT JOIN funcionario f ON v.funcionario_id_funcionario = f.id_funcionario
        LEFT JOIN modelo mo ON v.modelo_id_modelo = mo.id_modelo
        ORDER BY v.id_venda DESC";

$res = $conn->query($sql);

echo "<h1>Listar Venda</h1>";

if ($res === false) {
    echo "<p style='color:red;'>Erro na query: " . htmlspecialchars($conn->error) . "</p>";
    return;
}

if ($res->num_rows === 0) {
    echo "<p>Nenhuma venda encontrada.</p>";
    return;
}

echo "<p>Encontrou <b>{$res->num_rows}</b> resultado(s)</p>";
echo "<table class='table table-bordered table-striped table-hover'>";
echo "<thead><tr>
        <th>#</th>
        <th>Cliente</th>
        <th>Vendedor</th>
        <th>Modelo</th>
        <th>Valor</th>
        <th>Data</th>
        <th>Ações</th>
      </tr></thead>";
echo "<tbody>";

while ($row = $res->fetch_assoc()) {
    $id = htmlspecialchars($row['id_venda']);
    $cliente = htmlspecialchars($row['nome_cliente'] ?? ('ID ' . $row['cliente_id_cliente']));
    $vendedor = htmlspecialchars($row['nome_funcionario'] ?? ('ID ' . $row['funcionario_id_funcionario']));
    $modelo = htmlspecialchars($row['nome_modelo'] ?? ('ID ' . $row['modelo_id_modelo']));
    $valor = number_format((float)$row['valor_venda'], 2, ',', '.');
    $data = htmlspecialchars($row['data_venda']);

    echo "<tr>";
    echo "<td>{$id}</td>";
    echo "<td>{$cliente}</td>";
    echo "<td>{$vendedor}</td>";
    echo "<td>{$modelo}</td>";
    echo "<td>R$ {$valor}</td>";
    echo "<td>{$data}</td>";
    echo "<td>";
    echo "<button class='btn btn-success btn-sm' onclick=\"location.href='?page=editar-venda&id_venda={$id}'\">Editar</button> ";

    echo "<form method='post' action='?page=salvar-venda' style='display:inline-block;margin:0 4px;'>";
    echo "<input type='hidden' name='acao' value='excluir'>";
    echo "<input type='hidden' name='id_venda' value='{$id}'>";
    echo "<button type='submit' class='btn btn-danger btn-sm' onclick=\"return confirm('Tem certeza que deseja excluir?')\">Excluir</button>";
    echo "</form>";

    echo "</td>";
    echo "</tr>";
}

echo "</tbody></table>";
?>