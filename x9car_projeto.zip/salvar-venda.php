<?php
// salvar-venda.php (corrigido para evitar "Commands out of sync")
require_once __DIR__ . '/config.php';

if (!isset($conn) || !($conn instanceof mysqli)) {
    print "<script>alert('Conexão com o banco não encontrada. Verifique config.php'); location.href='?page=listar-venda';</script>";
    exit;
}

ini_set('display_errors', 1);
error_reporting(E_ALL);

$acao = $_REQUEST['acao'] ?? '';

switch ($acao) {
    case 'cadastrar':
        $cliente = intval($_POST['cliente_id_cliente'] ?? 0);
        $funcionario = intval($_POST['funcionario_id_funcionario'] ?? 0);
        $modelo = intval($_POST['modelo_id_modelo'] ?? 0);
        $valor = trim($_POST['valor_venda'] ?? '');
        $data = trim($_POST['data_venda'] ?? '');

        if ($cliente <= 0 || $funcionario <= 0 || $modelo <= 0 || $valor === '' || $data === '') {
            print "<script>alert('Todos os campos são obrigatórios'); location.href='?page=cadastrar-venda';</script>";
            exit;
        }

        // função auxiliar para checar existência via prepared statement de forma segura
        $exists = function($conn, $sql, $types, ...$params) {
            $stmt = $conn->prepare($sql);
            if (!$stmt) return [false, "prepare: " . $conn->error];
            if ($types !== '') $stmt->bind_param($types, ...$params);
            if (!$stmt->execute()) {
                $err = $stmt->error;
                $stmt->close();
                return [false, "execute: $err"];
            }
            // usar store_result() para permitir checagem de num_rows sem get_result()
            $stmt->store_result();
            $nr = $stmt->num_rows;
            $stmt->close();
            return [$nr > 0, null];
        };

        list($ok, $err) = $exists($conn, "SELECT id_cliente FROM cliente WHERE id_cliente = ?", "i", $cliente);
        if (!$ok) {
            $msg = $err ? "Erro no banco ($err)" : "Cliente inválido";
            print "<script>alert('{$msg}'); location.href='?page=cadastrar-venda';</script>";
            exit;
        }

        list($ok, $err) = $exists($conn, "SELECT id_funcionario FROM funcionario WHERE id_funcionario = ?", "i", $funcionario);
        if (!$ok) {
            $msg = $err ? "Erro no banco ($err)" : "Funcionário inválido";
            print "<script>alert('{$msg}'); location.href='?page=cadastrar-venda';</script>";
            exit;
        }

        list($ok, $err) = $exists($conn, "SELECT id_modelo FROM modelo WHERE id_modelo = ?", "i", $modelo);
        if (!$ok) {
            $msg = $err ? "Erro no banco ($err)" : "Modelo inválido";
            print "<script>alert('{$msg}'); location.href='?page=cadastrar-venda';</script>";
            exit;
        }

        $stmt = $conn->prepare("INSERT INTO venda (cliente_id_cliente, funcionario_id_funcionario, modelo_id_modelo, valor_venda, data_venda) VALUES (?, ?, ?, ?, ?)");
        if (!$stmt) {
            $err = $conn->error;
            die("<script>alert('Erro no banco: " . htmlspecialchars($err) . "'); location.href='?page=cadastrar-venda';</script>");
        }

        // tipos: i i i d s  (cliente, funcionario, modelo, valor (decimal), data (string))
        $valor_num = (float) str_replace(',', '.', $valor);
        $stmt->bind_param("iiids", $cliente, $funcionario, $modelo, $valor_num, $data);

        $ok = $stmt->execute();
        if ($ok) {
            $stmt->close();
            print "<script>alert('Venda cadastrada com sucesso!'); location.href='?page=listar-venda';</script>";
        } else {
            $err = $stmt->error ?: $conn->error;
            $stmt->close();
            die("<script>alert('Erro ao cadastrar venda: " . htmlspecialchars($err) . "'); location.href='?page=cadastrar-venda';</script>");
        }
        break;

    case 'editar':
        $id = intval($_POST['id_venda'] ?? 0);
        $cliente = intval($_POST['cliente_id_cliente'] ?? 0);
        $funcionario = intval($_POST['funcionario_id_funcionario'] ?? 0);
        $modelo = intval($_POST['modelo_id_modelo'] ?? 0);
        $valor = trim($_POST['valor_venda'] ?? '');
        $data = trim($_POST['data_venda'] ?? '');

        if ($id <= 0 || $cliente <= 0 || $funcionario <= 0 || $modelo <= 0 || $valor === '' || $data === '') {
            print "<script>alert('Dados inválidos'); location.href='?page=listar-venda';</script>";
            exit;
        }

        $stmt = $conn->prepare("UPDATE venda SET cliente_id_cliente=?, funcionario_id_funcionario=?, modelo_id_modelo=?, valor_venda=?, data_venda=? WHERE id_venda=?");
        if (!$stmt) {
            die("<script>alert('Erro no banco: " . htmlspecialchars($conn->error) . "'); location.href='?page=listar-venda';</script>");
        }
        $valor_num = (float) str_replace(',', '.', $valor);
        $stmt->bind_param("iiidsi", $cliente, $funcionario, $modelo, $valor_num, $data, $id);
        $ok = $stmt->execute();
        if ($ok) {
            $stmt->close();
            print "<script>alert('Editou com sucesso!'); location.href='?page=listar-venda';</script>";
        } else {
            $err = $stmt->error ?: $conn->error;
            $stmt->close();
            die("<script>alert('Erro ao editar venda: " . htmlspecialchars($err) . "'); location.href='?page=listar-venda';</script>");
        }
        break;

    case 'excluir':
        $id = intval($_POST['id_venda'] ?? 0);
        if ($id <= 0) {
            print "<script>alert('ID inválido'); location.href='?page=listar-venda';</script>";
            exit;
        }
        $stmt = $conn->prepare("DELETE FROM venda WHERE id_venda = ?");
        if (!$stmt) {
            die("<script>alert('Erro no banco: " . htmlspecialchars($conn->error) . "'); location.href='?page=listar-venda';</script>");
        }
        $stmt->bind_param("i", $id);
        $ok = $stmt->execute();
        if ($ok) {
            $stmt->close();
            print "<script>alert('Excluiu com sucesso!'); location.href='?page=listar-venda';</script>";
        } else {
            $err = $stmt->error ?: $conn->error;
            $stmt->close();
            die("<script>alert('Erro ao excluir venda: " . htmlspecialchars($err) . "'); location.href='?page=listar-venda';</script>");
        }
        break;

    default:
        header('Location: ?page=listar-venda');
        exit;
}
?>