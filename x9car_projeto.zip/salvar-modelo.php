<?php
// salvar-modelo.php - versão debug/robusta
require_once __DIR__ . '/config.php';

// mostrar erros temporariamente
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// garantir conexão
if (!isset($conn) || !($conn instanceof mysqli)) {
    die("<script>alert('Conexão com o banco não encontrada. Verifique config.php'); history.back();</script>");
}

// exibir dados recebidos (útil para debug)
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die("<script>alert('A página deve ser acessada via POST'); location.href='?page=cadastrar-modelo';</script>");
}

echo "<!-- debug: POST recebido: " . htmlspecialchars(json_encode($_POST)) . " -->";

$acao = $_REQUEST['acao'] ?? '';
if ($acao !== 'cadastrar' && $acao !== 'editar' && $acao !== 'excluir') {
    die("<script>alert('Ação inválida'); location.href='?page=listar-modelo';</script>");
}

switch ($acao) {
    case 'cadastrar':
        $marca = intval($_POST['marca_id_marca'] ?? 0);
        $nome = trim($_POST['nome_modelo'] ?? '');
        $cor = trim($_POST['cor_modelo'] ?? '');
        $ano = trim($_POST['ano_modelo'] ?? '');
        $tipo = trim($_POST['tipo_modelo'] ?? '');

        if ($marca <= 0 || $nome === '') {
            die("<script>alert('Marca e nome são obrigatórios'); location.href='?page=cadastrar-modelo';</script>");
        }

        // checar existência da marca
        $chk = $conn->prepare("SELECT id_marca FROM marca WHERE id_marca = ?");
        if (!$chk) die("<script>alert('Erro no banco: " . htmlspecialchars($conn->error) . "'); location.href='?page=cadastrar-modelo';</script>");
        $chk->bind_param("i", $marca);
        $chk->execute();
        $res_chk = $chk->get_result();
        if (!$res_chk || $res_chk->num_rows === 0) {
            die("<script>alert('Marca selecionada não existe'); location.href='?page=cadastrar-modelo';</script>");
        }

        $stmt = $conn->prepare("INSERT INTO modelo (nome_modelo, cor_modelo, ano_modelo, tipo_modelo, marca_id_marca) VALUES (?, ?, ?, ?, ?)");
        if (!$stmt) {
            die("<script>alert('Erro prepare: " . htmlspecialchars($conn->error) . "'); location.href='?page=cadastrar-modelo';</script>");
        }
        $stmt->bind_param("ssssi", $nome, $cor, $ano, $tipo, $marca);
        $ok = $stmt->execute();
        if ($ok) {
            // sucesso
            echo "<script>alert('Cadastrou com sucesso!'); location.href='?page=listar-modelo';</script>";
        } else {
            // mostrar erro do DB
            $err = $stmt->error ?: $conn->error;
            die("<script>alert('Erro ao cadastrar: " . htmlspecialchars($err) . "'); location.href='?page=cadastrar-modelo';</script>");
        }
        break;

    case 'editar':
        $id = intval($_POST['id_modelo'] ?? 0);
        $marca = intval($_POST['marca_id_marca'] ?? 0);
        $nome = trim($_POST['nome_modelo'] ?? '');
        if ($id <= 0 || $marca <= 0 || $nome === '') {
            die("<script>alert('Dados inválidos'); location.href='?page=listar-modelo';</script>");
        }
        $stmt = $conn->prepare("UPDATE modelo SET nome_modelo = ?, cor_modelo = ?, ano_modelo = ?, tipo_modelo = ?, marca_id_marca = ? WHERE id_modelo = ?");
        $stmt->bind_param("ssssii", $nome, $cor, $ano, $tipo, $marca, $id);
        if ($stmt->execute()) {
            echo "<script>alert('Editou com sucesso!'); location.href='?page=listar-modelo';</script>";
        } else {
            $err = $stmt->error ?: $conn->error;
            die("<script>alert('Erro ao editar: " . htmlspecialchars($err) . "'); location.href='?page=listar-modelo';</script>");
        }
        break;

    case 'excluir':
        $id = intval($_POST['id_modelo'] ?? 0);
        if ($id <= 0) die("<script>alert('ID inválido'); location.href='?page=listar-modelo';</script>");
        $stmt = $conn->prepare("DELETE FROM modelo WHERE id_modelo = ?");
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            echo "<script>alert('Excluiu com sucesso!'); location.href='?page=listar-modelo';</script>";
        } else {
            $err = $stmt->error ?: $conn->error;
            die("<script>alert('Erro ao excluir: " . htmlspecialchars($err) . "'); location.href='?page=listar-modelo';</script>");
        }
        break;
}
?>