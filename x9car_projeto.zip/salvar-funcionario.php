<?php
// incluir conexão - ajusta o caminho se config.php estiver em outra pasta
require_once __DIR__ . '/config.php';

// checar conexão
if (!isset($conn) || !($conn instanceof mysqli)) {
    print "<script>alert('Conexão com o banco não encontrada. Verifique config.php'); location.href='?page=listar-funcionario';</script>";
    exit;
}

// Aceitar apenas POST para ações que modificam dados
$acao = $_REQUEST['acao'] ?? '';

switch ($acao) {
    case 'cadastrar':
        $nome = trim($_POST['nome_funcionario'] ?? '');
        $email = trim($_POST['email_funcionario'] ?? '');
        $telefone = trim($_POST['telefone_funcionario'] ?? '');

        if ($nome === '') {
            print "<script>alert('Nome obrigatório'); location.href='?page=cadastrar-funcionario';</script>";
            exit;
        }

        $stmt = $conn->prepare("INSERT INTO funcionario (nome_funcionario, email_funcionario, telefone_funcionario) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $nome, $email, $telefone);
        $ok = $stmt->execute();
        if ($ok) {
            print "<script>alert('Cadastrou com sucesso!'); location.href='?page=listar-funcionario';</script>";
        } else {
            print "<script>alert('Erro ao cadastrar'); location.href='?page=listar-funcionario';</script>";
        }
        break;

    case 'editar':
        $id = intval($_POST['id_funcionario'] ?? 0);
        $nome = trim($_POST['nome_funcionario'] ?? '');
        $email = trim($_POST['email_funcionario'] ?? '');
        $telefone = trim($_POST['telefone_funcionario'] ?? '');

        if ($id <= 0 || $nome === '') {
            print "<script>alert('Dados inválidos'); location.href='?page=listar-funcionario';</script>";
            exit;
        }

        $stmt = $conn->prepare("UPDATE funcionario SET nome_funcionario = ?, email_funcionario = ?, telefone_funcionario = ? WHERE id_funcionario = ?");
        $stmt->bind_param("sssi", $nome, $email, $telefone, $id);
        $ok = $stmt->execute();
        if ($ok) {
            print "<script>alert('Editou com sucesso!'); location.href='?page=listar-funcionario';</script>";
        } else {
            print "<script>alert('Erro ao editar'); location.href='?page=listar-funcionario';</script>";
        }
        break;

    case 'excluir':
        $id = intval($_POST['id_funcionario'] ?? 0);
        if ($id <= 0) {
            print "<script>alert('ID inválido'); location.href='?page=listar-funcionario';</script>";
            exit;
        }

        $stmt = $conn->prepare("DELETE FROM funcionario WHERE id_funcionario = ?");
        $stmt->bind_param("i", $id);
        $ok = $stmt->execute();
        if ($ok) {
            print "<script>alert('Excluiu com sucesso!'); location.href='?page=listar-funcionario';</script>";
        } else {
            print "<script>alert('Erro ao excluir'); location.href='?page=listar-funcionario';</script>";
        }
        break;

    default:
        header('Location: ?page=listar-funcionario');
        exit;
}
?>