<?php
// cadastrar-modelo.php
require_once __DIR__ . '/config.php';

// carregar marcas para o select
$marcas = [];
if (isset($conn) && ($conn instanceof mysqli)) {
    $res = $conn->query("SELECT id_marca, nome_marca FROM marca ORDER BY nome_marca");
    if ($res) {
        while ($m = $res->fetch_assoc()) {
            $marcas[] = $m;
        }
    }
}
?>
<h1>Cadastrar Modelo</h1>

<form action="?page=salvar-modelo" method="POST">
    <input type="hidden" name="acao" value="cadastrar">
    <div class="mb-3">
        <label>Marca</label>
        <select name="marca_id_marca" class="form-control" required>
            <option value="">Escolha</option>
            <?php
            if (!empty($marcas)) {
                foreach ($marcas as $m) {
                    $mid = htmlspecialchars($m['id_marca']);
                    $mnome = htmlspecialchars($m['nome_marca']);
                    echo "<option value='{$mid}'>{$mnome}</option>";
                }
            } else {
                echo "<option value=''>Não há marcas</option>";
            }
            ?>
        </select>
    </div>

    <div class="mb-3">
        <label>Nome</label>
        <input type="text" name="nome_modelo" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Cor</label>
        <input type="text" name="cor_modelo" class="form-control">
    </div>

    <div class="mb-3">
        <label>Ano</label>
        <input type="number" name="ano_modelo" class="form-control">
    </div>

    <div class="mb-3">
        <label>Tipo</label>
        <input type="text" name="tipo_modelo" class="form-control">
    </div>

    <div>
        <button type="submit" class="btn btn-primary">Enviar</button>
    </div>
</form>